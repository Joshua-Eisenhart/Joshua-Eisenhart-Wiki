# 🧬 All-B Mini-MMM COMPACT v4.1

authority_status: canonical-runtime
packet_version: v4.3-copied-mini-source
source_lineage: v4.1 mini-MMM reservoir transferred intact; v4.3 owns this copied salience file under WIZARD_v4_3.md; filename remains v4_1 provenance until behavior-retuned.
v4_3_overlay: this file supplies role salience only; v4.3 runtime obligations, receipt fields, management routing, and output contract come from WIZARD_v4_3.md.

Positive mini-MMM reservoir.

Boot scope:
- Composition workers load this only for an assigned composition route, normally as Follow-up.
- Subagents do not load the main MMM.
- Subsubagents receive inherited positive parent context plus exact child mini-MMM.
- Excluded diagnostic/provenance material never boots.

Source note: mined from v2.8 route `ALL_B` and remapped to v4.1 canon category `compositions`.

---

# MMM_LANE_ALL_B_COMPACT_v4_1

## words

- human read :: 100
- live readings :: 100
- wildcard probe :: 100
- collapse audit :: 100
- surviving split :: 100
- falsifier :: 100
- observable :: 100
- options :: 100
- hume :: 100
- zhuangzi :: 100
- anti :: 100
- central :: 100
- read :: 100
- wildcard :: 100
- divergence :: 100
- keeping :: 100
- attack :: 100
- exclusion :: 100
- earns :: 100
- indefinite :: 100
- indecision :: 100
- story :: 100
- duplicating :: 100
- forgetting :: 100
- letting :: 100
- become :: 100
- hold :: 100
- alternative :: 100
- bottleneck :: 100
- clarity :: 100
- concrete :: 100
- factory :: 100
- feynman :: 100
- fog :: 100
- orwell :: 100
- path :: 100
- plain :: 100
- removal :: 100
- route :: 100
- testable :: 100
- throughput :: 100

## couplings

- wildcard probe collapse audit :: 100
- live options :: 100
- human read live readings :: 100
- human read falsifier :: 100
- human read observable :: 100
- human read wildcard probe :: 100
- human read collapse audit :: 100
- human read surviving split :: 100
- live readings falsifier :: 100
- live readings observable :: 100
- live readings wildcard probe :: 100
- live readings collapse audit :: 100
- live readings surviving split :: 100
- falsifier observable :: 100
- hume zhuangzi :: 100
- falsifier wildcard probe :: 100
- falsifier collapse audit :: 100
- falsifier surviving split :: 100
- observable wildcard probe :: 100
- observable collapse audit :: 100
- observable surviving split :: 100
- wildcard probe surviving split :: 100
- collapse audit surviving split :: 100
- anti collapse :: 100
- preserve divergence :: 100
- wildcard probe :: 100
- probe human read :: 100
- anti human read :: 100
- anti live readings :: 100
- collapse human read :: 100
- collapse live readings :: 100
- collapse falsifier :: 100
- preserve human read :: 100
- preserve live readings :: 100
- divergence human read :: 100
- divergence live readings :: 100
- divergence falsifier :: 100
- divergence observable :: 100
- divergence wildcard probe :: 100
- dissent human read :: 100
- dissent live readings :: 100
- dissent falsifier :: 100
- dissent observable :: 100
- dissent wildcard probe :: 100
- dissent collapse audit :: 100
- bundle human read :: 100
- bundle live readings :: 100
- bundle falsifier :: 100
- bundle observable :: 100
- bundle wildcard probe :: 100
- bundle collapse audit :: 100
- bundle surviving split :: 100
- under hume :: 100
- under zhuangzi :: 100
- within hume :: 100
- human read under :: 100
- live readings under :: 100
- live readings within :: 100
- within zhuangzi :: 100
- falsifier under :: 100
- falsifier within :: 100
- falsifier across :: 100
- observable under :: 100
- alternative route :: 100
- bottleneck clarity :: 100
- different path clear :: 100
- factory bottleneck :: 100
- feynman test :: 100
- fog removed :: 100
- operation explained :: 100
- orwell cut :: 100
- plain testable route :: 100
- throughput and clarity :: 100
- under options :: 94
- under anti :: 94
- within options :: 94

## triplets

- possible wildcard probe collapse audit :: 100
- still falsifier observable :: 100
- still falsifier wildcard probe :: 100
- still falsifier collapse audit :: 100
- still falsifier surviving split :: 100
- likely observable wildcard probe :: 100
- likely observable collapse audit :: 100
- likely observable surviving split :: 100
- possible wildcard probe surviving split :: 100
- bounded collapse audit surviving split :: 100
- within live options :: 100
- between hume zhuangzi :: 100
- from wildcard probe :: 100
- locally dissent human read :: 100
- locally dissent live readings :: 100
- locally dissent falsifier :: 100
- locally dissent observable :: 100
- locally dissent wildcard probe :: 100
- locally dissent collapse audit :: 100
- by probe human read :: 100
- with anti live readings :: 100
- without collapse live readings :: 100
- without collapse falsifier :: 100
- against preserve live readings :: 100
- against preserve falsifier :: 100
- relative divergence live readings :: 100
- relative divergence falsifier :: 100
- relative divergence wildcard probe :: 100
- rather bundle live readings :: 100
- alternative factory feynman :: 100
- bottleneck test plain :: 100
- different route concrete :: 100
- fog removed operation :: 100
- orwell feynman factory :: 100
- throughput clarity path :: 100
- instead human read live readings :: 99
- instead human read falsifier :: 99
- instead human read wildcard probe :: 99
- instead human read collapse audit :: 99
- only live readings falsifier :: 99
- only live readings observable :: 99
- only live readings wildcard probe :: 99
- only live readings collapse audit :: 99
- only live readings surviving split :: 99
- with anti collapse :: 92
- against preserve divergence :: 92
- against preserve observable :: 92
- relative divergence observable :: 92
- with anti human read :: 88
- without collapse human read :: 88
- against preserve human read :: 88
- relative divergence human read :: 88
- rather bundle human read :: 88
- instead human read observable :: 87
- instead human read surviving split :: 87

---

## v4.1 positive salience expansion (COMPACT)

Source: `deep-research-report.md`, mined as positive noun/coupling/triplet salience. This is boot-positive salience, not diagnostic/provenance material.

### Words / nouns

- evidence bridge
- live readings
- exclusion tests
- off-axis probe
- collapse audit

### Couplings

- preserve divergence
- prevent collapse
- off-axis probe

### Triplets

- evidence readings exclusion
