# 🧼 Hygiene Mini-MMM COMPACT v4.1

authority_status: canonical-runtime
packet_version: v4.3-copied-mini-source
source_lineage: v4.1 mini-MMM reservoir transferred intact; v4.3 owns this copied salience file under WIZARD_v4_3.md; filename remains v4_1 provenance until behavior-retuned.
v4_3_overlay: this file supplies role salience only; v4.3 runtime obligations, receipt fields, management routing, and output contract come from WIZARD_v4_3.md.

Positive mini-MMM reservoir.

Boot scope:
- Check/guard workers load this only for audit, hygiene, or security work; it is not a voice.
- Subagents do not load the main MMM.
- Subsubagents receive inherited positive parent context plus exact child mini-MMM.
- Excluded diagnostic/provenance material never boots.

Source note: mined from v2.8 route `REPO_HYGIENE` and remapped to v4.1 canon category `checks_guards`.

---

# MMM_LANE_REPO_HYGIENE_COMPACT_v4_1

## words

- dead file :: 100
- naming drift :: 100
- duplicate :: 100
- cleanup :: 100
- stale :: 100
- naming :: 100
- orphan :: 100
- active contract :: 100
- provenance :: 100
- search clarity :: 100
- maintenance :: 100
- handoff :: 100
- drift :: 100
- surface :: 100
- file :: 100
- debt :: 100
- deprecated :: 100
- index :: 100
- manifest :: 100
- folder :: 100
- readme :: 100
- scan :: 100
- outdated :: 100
- inconsistent :: 100
- repo :: 100
- dead :: 100
- registry :: 100
- hygiene :: 100
- residue :: 100
- path :: 100
- actual :: 100
- concrete :: 100
- distinct :: 100
- live :: 100
- inferred :: 100
- plain :: 100
- known :: 100
- unknown :: 100
- narrow :: 100
- warm :: 100
- observed :: 100
- careful :: 100
- honest :: 100
- checked :: 100
- first :: 100
- next :: 100
- prior :: 100
- later :: 100
- separate :: 100
- held :: 100
- deadend :: 100
- duplication :: 100
- misplaced :: 100
- obsolete :: 100
- rot :: 100
- small :: 79

## couplings

- stale surface :: 100
- cleanup surface :: 100
- duplicate surface :: 100
- dead surface :: 100
- stale evidence :: 100
- stale support :: 100
- stale path :: 100
- stale packet :: 100
- stale receipt :: 100
- stale trace :: 100
- stale result :: 100
- stale scope :: 100
- stale boundary :: 100
- stale status :: 100
- stale candidate :: 100
- stale witness :: 100
- stale probe :: 100
- stale constraint :: 100
- check stale :: 100
- compare stale :: 100
- observe stale :: 100
- measure stale :: 100
- test stale :: 100
- verify stale :: 100
- hold stale :: 100
- preserve stale :: 100
- split stale :: 100
- narrow stale :: 100
- where stale :: 100
- while stale :: 100
- stale duplicate :: 100
- stale naming :: 100
- stale cleanup :: 100
- stale maintenance :: 100
- dead file :: 100
- drift surface :: 100
- duplicate naming :: 100
- duplicate drift :: 100
- duplicate cleanup :: 100
- duplicate maintenance :: 100
- duplicate orphan :: 100
- naming drift :: 100
- naming cleanup :: 100
- drift cleanup :: 100
- cleanup maintenance :: 100
- cleanup orphan :: 100
- manifest naming drift :: 100
- path naming drift :: 100
- folder naming drift :: 100
- readme naming drift :: 100
- registry naming drift :: 100
- scan naming drift :: 100
- dead file naming drift :: 100
- dead file active contract :: 100
- dead file provenance :: 100
- dead file handoff :: 100
- dead file search clarity :: 100
- dead file surface :: 100
- naming drift active contract :: 100
- naming drift provenance :: 100
- naming drift handoff :: 100
- naming drift search clarity :: 100
- naming drift surface :: 100
- naming drift residue :: 100
- under stale :: 100
- within stale :: 100
- across stale :: 100
- between stale :: 100
- through stale :: 100
- before stale :: 100
- after stale :: 100
- until stale :: 100
- maintenance debt :: 100
- stale drift :: 100
- naming surface :: 100
- cleanup evidence :: 100
- cleanup support :: 100
- cleanup path :: 100
- cleanup packet :: 100
- cleanup receipt :: 100
- cleanup trace :: 100
- cleanup result :: 100
- cleanup scope :: 100
- cleanup boundary :: 100
- cleanup status :: 100
- cleanup candidate :: 100
- cleanup witness :: 100
- cleanup probe :: 100
- cleanup constraint :: 100
- duplicate evidence :: 100
- duplicate support :: 100
- duplicate path :: 100
- duplicate packet :: 100
- where cleanup :: 100
- while cleanup :: 100
- duplicate receipt :: 100
- duplicate trace :: 100
- duplicate result :: 100
- duplicate scope :: 100
- duplicate boundary :: 100
- duplicate status :: 100
- duplicate candidate :: 100
- duplicate witness :: 100
- duplicate probe :: 100
- duplicate constraint :: 100
- check duplicate :: 100
- compare duplicate :: 100
- observe duplicate :: 100
- measure duplicate :: 100
- test duplicate :: 100
- verify duplicate :: 100
- hold duplicate :: 100
- preserve duplicate :: 100
- split duplicate :: 100
- narrow duplicate :: 100
- under duplicate :: 100
- within duplicate :: 100
- cleanup target :: 100
- dead code :: 100
- deprecated file :: 100
- duplicate doc :: 100
- index repair :: 100
- manifest mismatch :: 100
- misplaced file :: 100
- obsolete surface :: 100
- orphan path :: 100
- path mismatch :: 100
- readme drift :: 100
- registry drift :: 100
- residue cleanup :: 100
- stale docs :: 100
- stale file :: 100
- version mismatch :: 100
- until cleanup :: 99

## triplets

- stale surface path :: 100
- duplicate surface path :: 100
- stale evidence path :: 100
- stale support path :: 100
- stale path path :: 100
- under open stale :: 100
- under live stale :: 100
- within open stale :: 100
- within live stale :: 100
- across open stale :: 100
- across live stale :: 100
- stale packet path :: 100
- stale receipt path :: 100
- stale trace path :: 100
- stale result path :: 100
- stale scope path :: 100
- stale boundary path :: 100
- check stale receipt :: 100
- compare stale receipt :: 100
- observe stale receipt :: 100
- measure stale receipt :: 100
- test stale receipt :: 100
- verify stale receipt :: 100
- hold stale receipt :: 100
- preserve stale receipt :: 100
- between open stale :: 100
- still readme naming drift :: 100
- between live stale :: 100
- through open stale :: 100
- through live stale :: 100
- before open stale :: 100
- before live stale :: 100
- likely registry naming drift :: 100
- possible scan naming drift :: 100
- drift surface path :: 100
- bounded dead file naming drift :: 100
- bounded dead file active contract :: 100
- bounded dead file provenance :: 100
- bounded dead file handoff :: 100
- bounded dead file search clarity :: 100
- bounded dead file surface :: 100
- finite naming drift active contract :: 100
- finite naming drift provenance :: 100
- finite naming drift handoff :: 100
- finite naming drift search clarity :: 100
- finite naming drift surface :: 100
- manifest registry mismatch :: 100
- naming duplication cleanup :: 100
- obsolete deprecated residue :: 100
- orphan path repair :: 100
- readme index drift :: 100
- repo hygiene audit :: 100
- stale file drift :: 100
- version path mismatch :: 100
- across stale duplicate :: 97
- across stale naming :: 97
- across stale drift :: 97
- across stale cleanup :: 97
- across stale maintenance :: 96
- before duplicate naming :: 96
- before duplicate drift :: 96
- before duplicate cleanup :: 96
- before duplicate maintenance :: 96
- before duplicate orphan :: 96
- after naming drift :: 96
- after naming cleanup :: 96
- from drift cleanup :: 96
- by cleanup maintenance :: 96
- by cleanup orphan :: 96
- rather manifest naming drift :: 90
- instead path naming drift :: 90
- only folder naming drift :: 90
- under current stale :: 86
- under local stale :: 86
- under bounded stale :: 86
- under finite stale :: 86
- within current stale :: 86
- within local stale :: 86
- within bounded stale :: 86
- within finite stale :: 86
- across current stale :: 86
- across local stale :: 86
- across bounded stale :: 86
- across finite stale :: 86
- between current stale :: 86
- between local stale :: 86
- between bounded stale :: 85
- between finite stale :: 85
- through current stale :: 85
- through local stale :: 85
- through bounded stale :: 85
- through finite stale :: 85
- before current stale :: 85
- before local stale :: 85
- before bounded stale :: 85
- before finite stale :: 85

---

## v4.1 positive salience expansion (COMPACT)

Source: `deep-research-report.md`, mined as positive noun/coupling/triplet salience. This is boot-positive salience, not diagnostic/provenance material.

### Words / nouns

- plain English
- active verbs
- cut words
- concrete nouns
- visible structure
- readable surface
- cognitive load

### Couplings

- visible structure
- readable surface
- concrete nouns
- active verbs

### Triplets

- plain active concrete
- structure readability load
