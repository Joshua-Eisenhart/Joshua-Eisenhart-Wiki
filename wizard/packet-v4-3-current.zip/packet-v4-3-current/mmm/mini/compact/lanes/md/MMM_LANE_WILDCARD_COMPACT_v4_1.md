# 🃏 Wildcard Mini-MMM COMPACT v4.1

authority_status: canonical-runtime
packet_version: v4.3-copied-mini-source
source_lineage: v4.1 mini-MMM reservoir transferred intact; v4.3 owns this copied salience file under WIZARD_v4_3.md; filename remains v4_1 provenance until behavior-retuned.
v4_3_overlay: this file supplies role salience only; v4.3 runtime obligations, receipt fields, management routing, and output contract come from WIZARD_v4_3.md.

Positive mini-MMM reservoir.

Boot scope:
- Subagents load this only when assigned this lane. It is normally surfaced through Follow-up.
- Subagents do not load the main MMM.
- Subsubagents receive inherited positive parent context plus exact child mini-MMM.
- Excluded diagnostic/provenance material never boots.

Source note: mined from v2.8 route `WILDCARD` and remapped to v4.1 canon category `lanes`.

---

# MMM_LANE_WILDCARD_COMPACT_v4_1

## words

- unexpected :: 100
- unlock :: 100
- probe :: 100
- odd :: 100
- cheap test :: 100
- edge move :: 100
- upside :: 100
- small experiment :: 100
- wildcard :: 100
- surprise :: 100
- blocker :: 100
- bounded :: 100
- creative :: 100
- nonobvious :: 100
- strange :: 100
- door :: 100
- cheap :: 100
- unusual :: 100
- stress :: 100
- angle :: 100
- side :: 100
- leverage :: 100
- experiment :: 100
- fit :: 100
- path :: 100
- small :: 100
- route :: 100
- actual :: 100
- concrete :: 100
- distinct :: 100
- live :: 100
- inferred :: 100
- plain :: 100
- known :: 100
- unknown :: 100
- narrow :: 100
- warm :: 100
- stale :: 100
- observed :: 100
- careful :: 100
- honest :: 100
- checked :: 100
- first :: 100
- next :: 100
- prior :: 100
- later :: 100
- separate :: 100
- held :: 100
- returned :: 100
- apart :: 100
- found :: 100
- compared :: 100
- anomaly :: 100
- asymmetric :: 100
- bet :: 100
- edge :: 100
- inversion :: 100
- lateral :: 100
- option :: 100
- weird :: 100

## couplings

- unexpected probe :: 100
- wildcard probe :: 100
- unlock probe :: 100
- surprise probe :: 100
- odd probe :: 100
- probe :: 100
- unexpected :: 100
- unlock :: 100
- unexpected evidence :: 100
- unexpected support :: 100
- unexpected path :: 100
- unexpected surface :: 100
- unexpected packet :: 100
- unexpected receipt :: 100
- unexpected trace :: 100
- unexpected result :: 100
- unexpected scope :: 100
- unexpected boundary :: 100
- unexpected status :: 100
- unexpected candidate :: 100
- unexpected witness :: 100
- unexpected constraint :: 100
- check unexpected :: 100
- compare unexpected :: 100
- observe unexpected :: 100
- measure unexpected :: 100
- test unexpected :: 100
- verify unexpected :: 100
- hold unexpected :: 100
- preserve unexpected :: 100
- split unexpected :: 100
- narrow unexpected :: 100
- under unexpected :: 100
- within unexpected :: 100
- across unexpected :: 100
- between unexpected :: 100
- through unexpected :: 100
- before unexpected :: 100
- after unexpected :: 100
- until unexpected :: 100
- where unexpected :: 100
- while unexpected :: 100
- nonobvious probe :: 100
- probe evidence :: 100
- probe support :: 100
- probe path :: 100
- probe surface :: 100
- probe packet :: 100
- probe receipt :: 100
- probe trace :: 100
- probe result :: 100
- probe scope :: 100
- probe boundary :: 100
- probe status :: 100
- probe candidate :: 100
- probe witness :: 100
- probe probe :: 100
- probe constraint :: 100
- wildcard unexpected :: 100
- wildcard unlock :: 100
- surprise unexpected :: 100
- surprise unlock :: 100
- unexpected odd :: 100
- observe probe :: 100
- narrow probe :: 100
- until probe :: 100
- unexpected unlock :: 100
- odd unlock :: 100
- where probe :: 100
- while probe :: 100
- unlock evidence :: 100
- unlock support :: 100
- unlock path :: 100
- unlock surface :: 100
- unlock packet :: 100
- unlock receipt :: 100
- unlock trace :: 100
- unlock result :: 100
- unlock scope :: 100
- unlock boundary :: 100
- unlock status :: 100
- unlock candidate :: 100
- unlock witness :: 100
- unlock constraint :: 100
- check unlock :: 100
- compare unlock :: 100
- observe unlock :: 100
- measure unlock :: 100
- test unlock :: 100
- verify unlock :: 100
- hold unlock :: 100
- preserve unlock :: 100
- split unlock :: 100
- narrow unlock :: 100
- under unlock :: 100
- within unlock :: 100
- across unlock :: 100
- between unlock :: 100
- through unlock :: 100
- before unlock :: 100
- after unlock :: 100
- until unlock :: 100
- where unlock :: 100
- while unlock :: 100
- measure probe :: 100
- test probe :: 100
- verify probe :: 100
- preserve probe :: 100
- split probe :: 100
- under probe :: 100
- within probe :: 100
- across probe :: 100
- between probe :: 100
- through probe :: 100
- side probe :: 100
- before probe :: 100
- after probe :: 100
- wildcard evidence :: 100
- wildcard support :: 100
- wildcard path :: 100
- anomaly probe :: 100
- asymmetric upside :: 100
- edge case :: 100
- inversion test :: 100
- lateral move :: 100
- left field check :: 100
- non obvious probe :: 100
- small bet :: 100
- surprise route :: 100
- unexpected angle :: 100
- unlock move :: 100
- unusual route :: 100
- weird edge :: 100
- wildcard option :: 100

## triplets

- under unexpected probe :: 100
- under odd probe :: 100
- under unlock probe :: 100
- within unexpected probe :: 100
- within odd probe :: 100
- within unlock probe :: 100
- across unexpected probe :: 100
- across odd probe :: 100
- across unlock probe :: 100
- unexpected evidence path :: 100
- unexpected support path :: 100
- unexpected path path :: 100
- unexpected surface path :: 100
- under open unexpected :: 100
- unexpected packet path :: 100
- under live unexpected :: 100
- unexpected receipt path :: 100
- unexpected trace path :: 100
- unexpected result path :: 100
- unexpected scope path :: 100
- unexpected boundary path :: 100
- within open unexpected :: 100
- within live unexpected :: 100
- across open unexpected :: 100
- across live unexpected :: 100
- between unexpected probe :: 100
- between odd probe :: 100
- check unexpected receipt :: 100
- compare unexpected receipt :: 100
- observe unexpected receipt :: 100
- measure unexpected receipt :: 100
- test unexpected receipt :: 100
- verify unexpected receipt :: 100
- anomaly probe option :: 100
- asymmetric upside test :: 100
- inversion test route :: 100
- lateral move small :: 100
- non obvious probe :: 100
- surprise route unlock :: 100
- unexpected angle check :: 100
- weird edge case :: 100
- under wildcard unexpected :: 99
- under surprise unexpected :: 99
- under surprise unlock :: 99
- under unexpected odd :: 99
- under unexpected unlock :: 98
- under odd unlock :: 98
- within wildcard unexpected :: 97
- within surprise unexpected :: 97
- within surprise unlock :: 96
- within unexpected odd :: 96
- within unexpected unlock :: 96
- within odd unlock :: 96
- under bounded probe :: 94
- within bounded probe :: 94
- across bounded probe :: 94
- between bounded probe :: 94
- through bounded probe :: 94
- before bounded probe :: 94
- across wildcard unexpected :: 94
- across surprise unexpected :: 94
- across surprise unlock :: 94
- across unexpected odd :: 94
- across unexpected unlock :: 94
- across odd unlock :: 94
- between wildcard unexpected :: 93
- between surprise unexpected :: 93
- between surprise unlock :: 93
- between unexpected odd :: 93
- between unexpected unlock :: 93
- between odd unlock :: 93
- under bounded wildcard :: 86
- within bounded wildcard :: 86
- across bounded wildcard :: 86
- between bounded wildcard :: 86
- under bounded unexpected :: 85
- within bounded unexpected :: 85
- across bounded unexpected :: 85
- between bounded unexpected :: 85
- through bounded wildcard :: 85
- before bounded wildcard :: 85
- under current unexpected :: 85
- under local unexpected :: 85
- under finite unexpected :: 85
- within current unexpected :: 85
- within local unexpected :: 85
- within finite unexpected :: 85
- across current unexpected :: 85
- across local unexpected :: 85
- across finite unexpected :: 85
- between current unexpected :: 85
- between local unexpected :: 85
- through bounded unexpected :: 84
- before bounded unexpected :: 84
- under bounded unlock :: 81
- within bounded unlock :: 81
- across bounded unlock :: 81
- between bounded unlock :: 81

---

## v4.1 positive salience expansion (COMPACT)

Source: `deep-research-report.md`, mined as positive noun/coupling/triplet salience. This is boot-positive salience, not diagnostic/provenance material.

### Words / nouns

- probe
- scout
- excursion
- wedge
- unlock

### Couplings

- off-axis probe
- scout path
- unlock wedge

### Triplets

- probe scout unlock
