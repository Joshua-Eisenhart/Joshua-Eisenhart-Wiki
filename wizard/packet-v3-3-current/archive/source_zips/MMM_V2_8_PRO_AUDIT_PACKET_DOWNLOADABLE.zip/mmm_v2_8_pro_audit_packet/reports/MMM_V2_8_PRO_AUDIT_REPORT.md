# MMM v2.8 Pro Audit Report

## Result

**v2.8 is the strongest packet so far, but it should not be treated as final.** It has the right architecture in pieces: positive-only boot, route registry, acceptance gates, mixed-model wave proof artifacts, mini-MMM categories, and a real long-form Wizard guide. The main repair is structural and documentary: the actual full guide is buried as `WIZARD_GENERAL_FULL_GUIDE_v2_8.md`, while `WIZARD_GENERAL_FULL_REFERENCE_v2_8.md` is only 537 chars. That mismatch will cause agents to load the wrong “full” file.

## High-confidence passes

- Positive main-agent boot is clean: boot files checked did not reference negative/reference material.
- `reference_only_negative/` exists and is outside the boot path.
- Mini-MMM tiers exist across voices, lanes, checks/guards, system routes, compositions, and controller acts.
- v2.8 includes route registry and acceptance gates.
- v2.8 contains runtime proof artifacts under `runs/wizard_full_expanded_latest/`.
- Mixed-model run proof exists: `external_mixed_model_wave_summary.json` reports 10 valid live waves and attempted Sonnet, Opus, Codex, and Gemini routes.
- Voice mini-MMM load proof exists: `external_repair_load_proof_summary.json` reports 9/9 voice subagents loaded full voice mini-MMM files.
- Negative/reference material is not part of the checked boot files.

## Critical gaps

1. **Full reference naming is dangerous.** `WIZARD_GENERAL_FULL_REFERENCE_v2_8.md` is tiny, while `WIZARD_GENERAL_FULL_GUIDE_v2_8.md` is the actual full guide.
2. **Legacy source status is not clean enough.** The packet includes `WIZARD_SOURCE_EXTRACTION_HERMES_CLAUDE_CODEX_v2_8.md`, but v2.9 should explicitly mark old HERMES/SOUL/AGENTS/CLAUDE docs as legacy mining sources, not canon.
3. **Main MMM noun/salience field still has gaps.** Some salience anchors exist, but people/schools/systems/math/operator language is uneven. Marker scan found zero or near-zero counts for Wiener, Beer, Meadows, Toyota, cybernetics, Daoism, Confucian, OODA, Clausewitz, Sunzi, distinguishability, and manifold.
4. **Definitions are improved but not rich enough for debugging smaller versions.** Full definitions are ~21822 chars, but v2.9 should add nearest neighbors, salience drivers, associated people/schools/systems/methods, and math/operator associations per route.
5. **Follow-up logic should explicitly say lanes/compositions emerge from prior wave audits.** v2.8 is close, but v2.9 should make this canonical.
6. **Runtime adapters are not clearly separated.** v2.9 should add non-canon runtime adapters for Claude/Codex/Gemini/Hermes instead of blending old source material into universal core.

## Audit answers

1. Universal core / MMM / adapters / legacy / negative separation: **PARTIAL**. Structure exists but should be clearer.
2. Main boot positive-only: **PASS**.
3. Mini-MMMs assigned to subagents: **PASS with wording patch needed**.
4. FULL docs actually full: **PARTIAL** due full-guide vs full-reference mismatch.
5. Definitions rich enough: **PARTIAL**.
6. Subagents required for visible routes: **PASS in direction**, strengthen in current universal core.
7. Voices separated from ordinary Follow-up: **PASS in direction**, reinforce.
8. LLM Council own wave/nested rounds: **PASS in direction**, enrich nested-round wording.
9. Audit/Hygiene/Security as checks/guards/waves: **PASS**.
10. Follow-up Make full candidate bank: **PASS in direction**.
11. Follow-up Run/Scout prework: **PASS in direction**.
12. Follow-up Audit/Improve final prompts: **PASS in direction**.
13. Header wave/subagent truth: **PASS in run output, needs standard template**.
14. Footer cognitive-load reduction: **PARTIAL**.
15. Runtime adapters non-canon: **PARTIAL**.
16. Legacy docs quarantined: **PARTIAL**.
17. Negative reference-only: **PASS**.
18. Main/mini-MMM noun salience: **PARTIAL / needs expansion**.
19. FULL mini-MMMs rich enough: **PARTIAL**.
20. COMPACT/ULTRA useful: **PASS with ongoing behavior testing needed**.

## Recommendation

Do not rebuild immediately. Run targeted deep research for salience expansion, then build v2.9 with a clean folder separation:

- `universal_core/`
- `mmm/`
- `definitions/`
- `boot_rules/`
- `runtime_adapters/`
- `legacy_mining/`
- `reference_only_negative/`
- `archive/`
- `audit/`
