# MMM v2.8 Fullness Gap Report

## Doc size scan

```json
{
  "NEW_THREAD_POSITIVE_MMM_BOOT_PROMPT_v2_8.md": {
    "chars": 427,
    "lines": 17
  },
  "README_BOOT_ORDER_v2_8.md": {
    "chars": 732,
    "lines": 25
  },
  "SUBAGENT_POSITIVE_MINI_MMM_BOOT_PROMPT_v2_8.md": {
    "chars": 407,
    "lines": 20
  },
  "SUBSUBAGENT_POSITIVE_MINI_MMM_BOOT_PROMPT_v2_8.md": {
    "chars": 462,
    "lines": 23
  },
  "WIZARD_ACCEPTANCE_GATES_v2_8.md": {
    "chars": 4723,
    "lines": 121
  },
  "WIZARD_EMOJI_MAP_v2_8.md": {
    "chars": 427,
    "lines": 7
  },
  "WIZARD_FOLLOWUP_FORMAT_v2_8.md": {
    "chars": 3796,
    "lines": 94
  },
  "WIZARD_GENERAL_COMPACT_v2_8.md": {
    "chars": 492,
    "lines": 16
  },
  "WIZARD_GENERAL_FULL_GUIDE_v2_8.md": {
    "chars": 48809,
    "lines": 1318
  },
  "WIZARD_GENERAL_FULL_REFERENCE_v2_8.md": {
    "chars": 537,
    "lines": 13
  },
  "WIZARD_GENERAL_STANDARD_v2_8.md": {
    "chars": 1629,
    "lines": 67
  },
  "WIZARD_GENERAL_ULTRA_v2_8.md": {
    "chars": 274,
    "lines": 8
  },
  "WIZARD_HEADER_FOOTER_TEMPLATES_v2_8.md": {
    "chars": 187,
    "lines": 8
  },
  "WIZARD_ROUTE_REGISTRY_v2_8.md": {
    "chars": 2978,
    "lines": 34
  },
  "WIZARD_SOURCE_EXTRACTION_HERMES_CLAUDE_CODEX_v2_8.md": {
    "chars": 11322,
    "lines": 289
  }
}
```

## Main finding

The actual full guide exists and is large: `current/WIZARD_GENERAL_FULL_GUIDE_v2_8.md` has 48809 chars. But the file named `WIZARD_GENERAL_FULL_REFERENCE_v2_8.md` has only 537 chars. This naming mismatch is the main fullness failure.

## Definitions

Full definitions have 21822 chars. This is useful, but v2.9 should add richer debugging fields:

- nearest neighbors
- non-job
- receipt requirement
- salience drivers
- associated people
- associated schools / traditions
- associated systems / methods
- math / operator / geometry associations
- legacy mined notes

## Tier separation

The tier separation exists, but the v2.9 validation should explicitly check:
- FULL > STANDARD > COMPACT > ULTRA by content richness
- FULL is source of truth for debugging
- COMPACT/ULTRA are not the only usable docs
- FULL mini-MMMs are rich enough for short-lived workers
