# MMM v2.8 Doc Structure Patch Plan

## Patch posture

Patch into v2.9. Do not redesign.

## 1. Rename / promote FULL guide

- Promote `current/WIZARD_GENERAL_FULL_GUIDE_v2_8.md` to `universal_core/WIZARD_UNIVERSAL_CORE_FULL_v2_9.md`.
- Retire or delete tiny `WIZARD_GENERAL_FULL_REFERENCE_v2_8.md`.
- Add a validation check: FULL docs must be materially larger than STANDARD/COMPACT/ULTRA.

## 2. Add universal_core/

Create:
- `WIZARD_UNIVERSAL_CORE_FULL_v2_9.md`
- `WIZARD_UNIVERSAL_CORE_STANDARD_v2_9.md`
- `WIZARD_UNIVERSAL_CORE_COMPACT_v2_9.md`
- `WIZARD_UNIVERSAL_CORE_ULTRA_v2_9.md`
- `WIZARD_HEADER_FOOTER_TEMPLATES_v2_9.md`
- `WIZARD_FOLLOWUP_SYSTEM_v2_9.md`
- `WIZARD_ROUTE_REGISTRY_v2_9.md/json`
- `WIZARD_ACCEPTANCE_GATES_v2_9.md/json`

## 3. Keep MMM as the universal salience layer

Create:
- `mmm/main/`
- `mmm/mini/`

Main agent boots main MMM only.
Subagents boot assigned mini-MMM only.

## 4. Add runtime adapters, not canon

Create:
- `runtime_adapters/README_ADAPTERS_NOT_CANON.md`
- `CLAUDE_ADAPTER_NOT_CANON.md`
- `CODEX_ADAPTER_NOT_CANON.md`
- `GEMINI_ADAPTER_NOT_CANON.md`
- `HERMES_ADAPTER_NOT_CANON.md`

## 5. Add legacy mining quarantine

Create:
- `legacy_mining/README_LEGACY_NOT_CANON.md`
- `EXTRACTED_USEFUL_PATTERNS.md`
- `REJECTED_LEGACY_PATTERNS.md`

## 6. Enrich definitions after deep research

Definitions FULL should gain:
- nearest neighbors
- non-job
- salience drivers
- associated people/schools/systems/methods
- math/operator/geometry associations
- legacy mined notes

## 7. Enrich MMMs after deep research

Do not make final lexical changes until Deep Research provides expansion candidates.

## 8. Preserve negative quarantine

Keep:
- `reference_only_negative/README_NEGATIVE_REFERENCE_ONLY_v2_9.md`

Ensure no boot file references it.
