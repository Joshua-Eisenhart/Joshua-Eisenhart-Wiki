# MMM v2.8 Canonical Core Summary

## Current canon

1. Positive MMM boots first.
2. Negative / banned / contrast material never boots.
3. Main agent loads big/main MMM, not all voice mini-MMMs.
4. Subagents load assigned mini-MMM before task card.
5. Subsubagents load inherited positive context plus exact child mini-MMM.
6. Wizard requires real multi-wave subagent execution.
7. A visible voice/lane/check/council/composition has not run unless a real subagent ran it or it is marked blocked/deferred.
8. Visible routes require spawned / blocked / deferred truth.
9. Controller synthesis is not execution.
10. Voices run in voice waves, not ordinary follow-up.
11. LLM Council has its own wave, with nested rounds/subagents when runtime supports it.
12. Audit, Hygiene, and Security are checks/guards/waves, not voices and not lanes.
13. Lanes and compositions emerge from audits of voices, LLM Council, general output, route registry, and acceptance gates.
14. Follow-up generation uses three waves: Make/Assembly, Run/Scout, Audit/Improve.
15. Final Follow-up is the audited useful subset unless the user asks for full candidate bank.
16. Output must reduce cognitive load, not become a worker log.
17. Header/footer should expose useful route truth cleanly.
18. FULL docs must be genuinely full; smaller docs derive from full.
19. MMMs need positive nouns, people, schools, systems, methods, operators, math/geometry, and salience-driver phrase clusters.
20. Rules are default/general and later tuned per runtime/model.

## Hierarchy

1. User-stated canon.
2. Positive MMM boot law.
3. Real subagent-wave truth.
4. Main-agent big MMM / subagent mini-MMM separation.
5. General Wizard format and cognitive-load reduction.
6. Legacy docs mined only for useful parts.
7. Runtime adapters marked as tunable adapters, not canon.
