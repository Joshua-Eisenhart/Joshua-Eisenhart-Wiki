# MMM v2.8 Legacy Mining Report

## Status

The uploaded HERMES / SOUL / SUBAGENT_BOOT / AGENTS / CLAUDE docs are **not canon**. They are old broken predecessor systems. v2.9 should mine them, not obey them.

## Metrics

{
  "HERMES(3).md": {
    "exists": true,
    "chars": 36158,
    "lines": 485,
    "subagent_mentions": 22,
    "wave_mentions": 13,
    "followup_mentions": 55,
    "receipt_mentions": 36,
    "mmm_mentions": 16
  },
  "SOUL(3).md": {
    "exists": true,
    "chars": 15331,
    "lines": 273,
    "subagent_mentions": 1,
    "wave_mentions": 0,
    "followup_mentions": 5,
    "receipt_mentions": 7,
    "mmm_mentions": 0
  },
  "SUBAGENT_BOOT(3).md": {
    "exists": true,
    "chars": 8206,
    "lines": 171,
    "subagent_mentions": 16,
    "wave_mentions": 0,
    "followup_mentions": 2,
    "receipt_mentions": 9,
    "mmm_mentions": 9
  },
  "AGENTS(3).md": {
    "exists": true,
    "chars": 33401,
    "lines": 500,
    "subagent_mentions": 5,
    "wave_mentions": 36,
    "followup_mentions": 42,
    "receipt_mentions": 51,
    "mmm_mentions": 16
  },
  "CLAUDE(3).md": {
    "exists": true,
    "chars": 30011,
    "lines": 427,
    "subagent_mentions": 9,
    "wave_mentions": 0,
    "followup_mentions": 15,
    "receipt_mentions": 25,
    "mmm_mentions": 0
  }
}

## Useful mined patterns

### HERMES

Useful:
- visible scaffold discipline
- Results as compact receipt summary
- follow-up as future-choice menu
- footer/header rail concept
- cognitive-load compression
- separation of body, Results, Follow-up, Hygiene/Security, Footer

Reject:
- any system-specific literal scaffold that conflicts with universal core
- any old route semantics that treat visible routes as menu theater
- any rule that lets controller-local reasoning count as workerized plurality

### SOUL

Useful:
- Hume as bridge voice
- Zhuangzi as anti-collapse
- Feynman as operation/testability
- Orwell as anti-fog
- Popper as falsifier
- Factory / Strategy distinction
- pushback as earned disagreement

Reject:
- voice-as-style framing
- any voice output without subagent receipt
- old emoji mismatches

### SUBAGENT_BOOT

Useful:
- salience-before-rules
- mini-MMM before task card
- task card minimum fields
- receipt discipline
- bounded subsubagent use

Reject:
- treating boot docs as complete doctrine
- any unclear status between controller-local and spawned worker

### AGENTS / Codex

Useful:
- no fake plurality
- spawned / blocked / deferred truth
- worker budget accounting
- wave registry
- mini-MMM law
- direct/narrow exception
- route registry fields

Reject:
- Codex-specific capacity/config as universal canon
- any Codex-only paths or runtime assumptions in universal core

### CLAUDE

Useful:
- anti-collapse doctrine
- body-before-follow-up
- subagent execution model
- LLM Council concept
- audit integration
- follow-up field structure
- strong pushback and no placation

Reject:
- treating Claude model routing as universal
- forcing every interactive answer into full Claude-style menu
- any old follow-up rule that makes special waves ordinary menu items

## Adapter extraction target

v2.9 should include:
- `runtime_adapters/CLAUDE_ADAPTER_NOT_CANON.md`
- `runtime_adapters/CODEX_ADAPTER_NOT_CANON.md`
- `runtime_adapters/GEMINI_ADAPTER_NOT_CANON.md`
- `runtime_adapters/HERMES_ADAPTER_NOT_CANON.md`

Adapters can tune the general system locally, but cannot override:
- positive MMM first
- negative never boots
- real subagent wave truth
- spawned / blocked / deferred
- main MMM vs mini-MMM separation
