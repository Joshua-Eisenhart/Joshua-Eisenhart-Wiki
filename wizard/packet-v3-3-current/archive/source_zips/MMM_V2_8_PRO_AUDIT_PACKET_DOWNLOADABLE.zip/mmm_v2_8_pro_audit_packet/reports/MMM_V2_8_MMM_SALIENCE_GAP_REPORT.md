# MMM v2.8 MMM Salience Gap Report

## Marker scan in main full MMM

```json
{
  "hume": 33,
  "popper": 1,
  "feynman": 1,
  "zhuangzi": 37,
  "orwell": 1,
  "wiener": 0,
  "beer": 0,
  "meadows": 0,
  "toyota": 0,
  "kanban": 146,
  "z3": 2,
  "smt": 1,
  "sat": 7,
  "unsat": 4,
  "operator": 3,
  "manifold": 0,
  "tensor": 1,
  "measurement": 3,
  "distinguishability": 0,
  "ooda": 0,
  "clausewitz": 0,
  "sunzi": 0,
  "owasp": 0,
  "least privilege": 24,
  "cybernetics": 0,
  "daoism": 0,
  "confucian": 0,
  "quine": 0,
  "peirce": 0,
  "mach": 1,
  "bacon": 0,
  "ockham": 0,
  "bayes": 0,
  "control theory": 0
}
```

## Main finding

The main full MMM has a large lexical reservoir, but the positive noun/person/school/system/math salience is uneven.

Strong or present:
- Hume
- Zhuangzi
- kanban
- least privilege
- SAT / UNSAT
- some Z3 / SMT

Weak or missing:
- Norbert Wiener
- Stafford Beer
- Donella Meadows
- Toyota as named system source
- cybernetics as named school
- Daoism / Confucianism as explicit terms
- OODA / Boyd
- Clausewitz / Sunzi
- OWASP
- distinguishability
- manifold
- density matrix / CPTP / operator language is too thin

## v2.9 expansion target

Do not generate final lexical MMMs in this pass. Deep Research should produce positive salience candidates for:

- people
- schools
- systems
- methods
- operators
- math/geometry objects
- phrase clusters
- nouns / verbs / adjectives
- source-adjacent couplings and triplets

## Route-specific salience needs

- Hume: Hume, common life, testimony, proportioned belief, modest judgment, empiricism.
- Popper: conjecture, refutation, severe test, counterinstance, critical rationalism.
- Feynman: apparatus, measurement, physical intuition, not fooling yourself.
- Zhuangzi: Daoism, wandering, perspective, transformation, non-forcing.
- Orwell: plain English, concrete nouns, active verbs, euphemism, dead metaphor.
- Systems: Wiener, Beer, Meadows, feedback, stocks/flows, delays, emergence.
- Factory: Toyota, TPS, kanban, jidoka, andon, takt, pull, reliability, incident review.
- Strategy: Boyd/OODA, campaign, tempo, reserve, decisive point, retreat.
- Audit/Hygiene/Security: provenance, receipt, traceability, readability, OWASP, least privilege.
- LLM Council: model variance, independent assessment, dissent preservation, peer review.
- Formal methods: Z3, SMT, model checking, invariant, witness, counterexample, finite model, equivalence class, distinguishability.
