# MMM v2.8 Runtime Contradiction Table

| ID | Issue | Why it matters | Severity | v2.9 patch |
|---|---|---|---|---|
| C1 | FULL reference name mismatch | current/WIZARD_GENERAL_FULL_REFERENCE_v2_8.md is tiny; WIZARD_GENERAL_FULL_GUIDE_v2_8.md is the actual full guide. | High | Promote/rename FULL_GUIDE as the active FULL_REFERENCE in v2.9. |
| C2 | Legacy docs not clearly non-canon | Legacy extraction file exists but system should explicitly say old docs are mining inputs only. | High | Add legacy_mining/README_LEGACY_NOT_CANON.md and runtime_adapters/. |
| C3 | Universal/current duplication | universal_mmm and main_mmm may imply separate concepts when user views them as same layer. | Medium | Either unify as mmm/main or explicitly define why universal_mmm is alias/reference. |
| C4 | Full definitions lack rich associations | Definitions explain roles but not enough people/schools/systems/methods/math associations. | Medium | Deep-research salience expansion and enrich FULL definitions. |
| C5 | Noun salience uneven | Main MMM marker scan has zero for several key people/schools/systems. | High | Expand positive salience nouns in main and mini full MMMs. |
| C6 | Follow-up emergence under-specified | Follow-ups should explicitly emerge from voice/council/audit/general output, not just static menu. | Medium | Patch follow-up format to say candidate bank is assembled from prior wave receipts. |
| C7 | Adapter boundaries incomplete | Claude/Codex/Gemini/Hermes runtime differences are not cleanly separated from universal core. | Medium | Add non-canon runtime adapters. |
