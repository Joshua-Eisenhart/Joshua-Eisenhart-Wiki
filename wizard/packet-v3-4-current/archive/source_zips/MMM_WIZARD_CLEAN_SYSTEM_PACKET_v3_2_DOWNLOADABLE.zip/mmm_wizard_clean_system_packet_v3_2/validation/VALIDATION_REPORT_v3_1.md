# v3.1 Validation Report

- two_sizes_only: True
- subagent_does_not_boot_main_mmm: True
- audit_not_default_section: True
- quality_score_footer_only: True
- definitions_separate_from_universal_core: True
- negative_reference_never_boot: True
- full_core_rewritten: True
- compact_core_rewritten: True
