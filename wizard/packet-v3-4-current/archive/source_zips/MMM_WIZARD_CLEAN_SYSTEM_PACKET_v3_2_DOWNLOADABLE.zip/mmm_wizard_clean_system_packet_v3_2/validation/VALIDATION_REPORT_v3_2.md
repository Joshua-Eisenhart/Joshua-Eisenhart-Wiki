# v3.2 Validation Report

- embedded_runtime_definitions: True
- followup_maps_prior_waves_to_lanes_compositions: True
- single_full_wizard_max_option: True
- subagent_does_not_boot_main_mmm: True
- audit_hygiene_security_checks_guards: True
- definitions_still_separate_for_debugging: True
