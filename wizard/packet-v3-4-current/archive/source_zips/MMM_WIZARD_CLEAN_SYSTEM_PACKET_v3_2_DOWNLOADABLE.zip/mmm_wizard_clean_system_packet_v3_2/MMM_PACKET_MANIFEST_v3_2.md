# MMM Packet Manifest v3.2

- name: MMM_WIZARD_CLEAN_SYSTEM_PACKET
- version: 3.2
- created_utc: 2026-04-29T08:02:31.465329+00:00
- purpose: embed runtime definitions and correct follow-up generation pipeline
- active_sizes: ['full', 'compact']
