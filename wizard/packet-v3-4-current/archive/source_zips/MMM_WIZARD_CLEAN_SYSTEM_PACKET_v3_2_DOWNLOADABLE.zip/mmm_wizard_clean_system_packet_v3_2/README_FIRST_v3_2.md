# MMM Wizard Clean System Packet v3.2

## What this fixes

- Full universal core includes embedded runtime definitions.
- Definitions still exist separately for debugging.
- Follow-up generation now clearly derives from voices, output, LLM Council, checks/guards, route registry, and acceptance gates.
- Follow-up Make maps all candidate material into lanes/compositions.
- Follow-up Run/Scout tests candidates in temporary worker/file space when prework is active.
- Follow-up Audit/Improve creates the final useful menu.
- A single max option exists: 🧙🏽‍♂️ Full Wizard.
- All-A / All-B / All-C / Full Wizard are clearly laid out.
- Audit/Hygiene/Security remain checks/guards, not voices or lanes.
- Subagents still do not boot the main MMM.

## Read first

1. `universal_core/WIZARD_UNIVERSAL_CORE_FULL_v3_2.md`
2. `mmm/main/compact/md/MMM_MAIN_COMPACT_v3_1.md`
3. `definitions/full/md/MMM_DEFINITIONS_FULL_v3_1.md`
4. `universal_core/WIZARD_UNIVERSAL_CORE_COMPACT_v3_2.md`
