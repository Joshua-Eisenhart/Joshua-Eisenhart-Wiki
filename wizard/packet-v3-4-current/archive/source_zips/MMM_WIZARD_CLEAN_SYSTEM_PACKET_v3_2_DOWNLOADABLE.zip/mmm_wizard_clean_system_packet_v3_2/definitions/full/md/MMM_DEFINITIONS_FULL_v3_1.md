# MMM Definitions FULL v3.1

## HUME

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** HUME preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** SYNTHESIS, AUDIT, POPPER

### Salience drivers

- David Hume
- association
- checked experience
- common life
- custom
- custom and habit
- custom habit belief
- empiricism
- experience
- experience and testimony
- experience testimony support
- fact observation experience
- fallibilism
- habit
- idea
- impression
- impression and idea
- impression idea association
- matter of fact
- memory and testimony
- memory testimony probability
- modest judgment
- ordinary common life
- ordinary language
- probability
- probable inference
- proportioned belief
- sentiment
- testimony
- testimony probability judgment

### People / schools / systems / methods

- David Hume
- empiricism
- ordinary language

## ZHUANGZI

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** ZHUANGZI preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** ALTERNATIVE, REFRAME, SYNTHESIS

### Salience drivers

- Daoism
- Zhuangzi
- butterfly dream
- convention
- goblet words
- live readings
- live readings exclusion
- multiple views
- multiple views held
- name path convention
- naming caution
- non-forcing
- non-forcing transformation
- parable
- path
- path perspective plurality
- perspective on perspectives
- perspectivism
- plurality of paths
- relational perspective
- skill story
- skillful wandering
- transformation
- unfixed distinction
- usefulness
- wandering
- wandering reading
- wandering transformation perspective

### People / schools / systems / methods

- Zhuangzi
- Daoism
- perspectivism

## FEYNMAN

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** FEYNMAN preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** ORWELL, POPPER

### Salience drivers

- Richard Feynman
- apparatus
- apparatus and measurement
- apparatus observable measurement
- calculation
- calibrated instrument
- calibration
- calibration measurement error
- comparison
- contact with nature
- do the experiment
- estimate
- example
- experiment
- instrument
- invalidating detail
- measured difference
- measurement
- observable
- observable and failure
- operation observable failure
- operational check
- phenomenon
- physical intuition
- physical picture
- report everything
- scientific integrity
- scientific integrity report
- setup
- setup measurement comparison

### People / schools / systems / methods

- Richard Feynman
- experimental physics

### Math / operator / geometry associations

- Z3
- SMT
- SAT
- UNSAT
- model checking
- invariant
- counterexample
- solver
- witness
- proof obligation
- finite model
- constraint satisfaction

## ORWELL

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** ORWELL preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** FEYNMAN, HYGIENE

### Salience drivers

- George Orwell
- abstract fog
- active verb agency
- active verbs
- active voice
- bad abstraction
- concrete naming
- concrete noun
- cut abstract fog
- cut the word
- dead metaphor
- euphemism
- everyday English
- inflated noun
- noun verb state
- passive hiding
- plain English
- plain concrete naming
- plain sentence
- political language
- say what happened
- short word
- stale phrase
- visible agency

### People / schools / systems / methods

- George Orwell
- plain English

## POPPER

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** POPPER preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** PUSHBACK, FEYNMAN, AUDIT

### Salience drivers

- Karl Popper
- basic statement
- basic statement corroboration
- bold hypothesis
- claim falsifier check
- conjecture
- conjecture and refutation
- conjecture refutation correction
- corroboration
- counterinstance
- critical discussion
- critical rationalism
- demarcation
- error correction
- falsifiability
- falsifier
- falsifier before agreement
- piecemeal testing
- problem conjecture refutation
- problem situation
- provisional corroboration
- refutation
- risky prediction
- risky prediction counterinstance
- severe test
- single counterinstance
- trial and error

### People / schools / systems / methods

- Karl Popper
- critical rationalism

### Math / operator / geometry associations

- Z3
- SMT
- SAT
- UNSAT
- model checking
- invariant
- counterexample
- solver
- witness
- proof obligation
- finite model
- constraint satisfaction

## PUSHBACK

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** PUSHBACK preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** POPPER, SECURITY

### Salience drivers

- Karl Popper
- activity
- agent
- audit trail
- basic statement
- basic statement corroboration
- benchmark
- bold hypothesis
- checked state
- claim falsifier check
- clean finding
- clean verdict
- conjecture
- conjecture and refutation
- conjecture refutation correction
- corroboration
- counterexample
- counterinstance
- critical discussion
- critical rationalism
- demarcation
- digital thread
- entity
- entity activity agent
- error correction
- evidence chain
- false closure
- falsifiability
- falsifier
- falsifier before agreement
- finding
- finding severity repair
- initial state
- path
- piecemeal testing
- problem conjecture refutation
- problem situation
- provenance
- provenance record
- provisional corroboration
- receipt
- receipt evidence chain
- refutation
- risky prediction
- risky prediction counterinstance
- route truth
- route truth audit
- severe test
- severity
- single counterinstance
- source pointer
- state path counterexample
- traceability
- trial and error

## FACTORY

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** FACTORY preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** SYSTEMS, STRATEGY

### Salience drivers

- Toyota Production System
- abnormality
- andon
- bottleneck
- flow rework leverage
- handoff
- handoff friction
- incident review
- inventory hides problem
- jidoka
- jidoka andon
- jidoka andon abnormality
- kaizen
- kanban
- lead time
- lean manufacturing
- observability
- pull system
- queue
- queue drag
- queue handoff bottleneck
- reliability engineering
- rework
- standard work
- standard work improvement
- takt time
- throughput constraint
- visible abnormality
- work in process

### People / schools / systems / methods

- Toyota Production System
- Taiichi Ohno
- lean manufacturing

## STRATEGY

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** STRATEGY preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** SYSTEMS, FACTORY

### Salience drivers

- Clausewitz
- John Boyd
- OODA
- OODA loop
- Sunzi
- campaign
- campaign sequence
- campaign tempo reserve
- center of gravity
- decisive point
- decisive point initiative
- disposition
- front timing resource
- initiative
- line of effort
- objective
- objective terrain disposition
- operational reach
- reserve
- retreat condition
- scarce resource
- sequence
- sequence resource retreat
- tempo
- tempo and reserve
- terrain

### People / schools / systems / methods

- John Boyd
- Sunzi
- Clausewitz
- OODA

## SYSTEMS

- **Category:** voices
- **Purpose:** method-specific subagent reasoning route
- **Unique job:** SYSTEMS preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** FACTORY, STRATEGY

### Salience drivers

- Donella Meadows
- Norbert Wiener
- Stafford Beer
- attractor
- balancing loop
- boundary attractor coupling
- buffer
- buffer and delay
- complex adaptive system
- controller
- coupling
- cybernetics
- delay
- emergence
- feedback
- feedback loop
- flow
- goal information feedback
- information flow
- leverage point
- loop incentive coupling
- monitor
- monitor controller feedback
- reinforcing loop
- second-order effect
- selection pressure
- stock
- stock flow delay
- stocks and flows
- system boundary

### People / schools / systems / methods

- Norbert Wiener
- Stafford Beer
- Donella Meadows
- cybernetics

### Math / operator / geometry associations

- Z3
- SMT
- SAT
- UNSAT
- model checking
- invariant
- counterexample
- solver
- witness
- proof obligation
- finite model
- constraint satisfaction

## DIRECT

- **Category:** lanes
- **Purpose:** follow-up / action-route candidate
- **Unique job:** DIRECT preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- SAT
- SMT
- SMT solver
- UNSAT
- Z3
- action artifact blocker
- artifact
- assumption
- boundary
- bounded move
- bounded verification
- branch
- branch tradeoff fallback
- candidate option
- changed frame
- channel
- constraint satisfaction
- counterexample
- counterexample trace
- density matrix
- density matrix channel
- equivalence class
- fallback
- finite model
- gate
- graph
- input system output system
- invariant
- invariant violation
- manifold
- model checking
- move
- objective
- off-axis probe
- operator
- operator channel
- option payoff deliverable
- premise boundary unit
- previous surface
- probe
- probe scout unlock
- proof obligation
- quantum channel
- real fork
- rollback
- route comparison
- scope
- scout
- solver
- solver witness model
- state path witness
- tensor
- theory invariant counterexample
- tradeoff
- tradeoff axis
- transition system trace
- unblock
- unit
- unlock
- wedge
- witness

### Math / operator / geometry associations

- Z3
- SMT
- SAT
- UNSAT
- model checking
- invariant
- counterexample
- solver
- witness
- proof obligation
- finite model
- constraint satisfaction

## ALTERNATIVE

- **Category:** lanes
- **Purpose:** follow-up / action-route candidate
- **Unique job:** ALTERNATIVE preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- action artifact blocker
- artifact
- assumption
- boundary
- bounded move
- branch
- branch tradeoff fallback
- candidate option
- changed frame
- fallback
- gate
- move
- objective
- off-axis probe
- option payoff deliverable
- premise boundary unit
- previous surface
- probe
- probe scout unlock
- real fork
- rollback
- route comparison
- scope
- scout
- tradeoff
- tradeoff axis
- unblock
- unit
- unlock
- wedge

## REFRAME

- **Category:** lanes
- **Purpose:** follow-up / action-route candidate
- **Unique job:** REFRAME preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- Daoism
- Zhuangzi
- action artifact blocker
- artifact
- assumption
- boundary
- bounded move
- branch
- branch tradeoff fallback
- butterfly dream
- candidate option
- changed frame
- convention
- fallback
- gate
- goblet words
- live readings
- live readings exclusion
- move
- multiple views
- multiple views held
- name path convention
- naming caution
- non-forcing
- non-forcing transformation
- objective
- off-axis probe
- option payoff deliverable
- parable
- path
- path perspective plurality
- perspective on perspectives
- perspectivism
- plurality of paths
- premise boundary unit
- previous surface
- probe
- probe scout unlock
- real fork
- relational perspective
- rollback
- route comparison
- scope
- scout
- skill story
- skillful wandering
- tradeoff
- tradeoff axis
- transformation
- unblock
- unfixed distinction
- unit
- unlock
- usefulness
- wandering
- wandering reading
- wandering transformation perspective
- wedge

## WILDCARD

- **Category:** lanes
- **Purpose:** follow-up / action-route candidate
- **Unique job:** WILDCARD preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- action artifact blocker
- artifact
- assumption
- boundary
- bounded move
- branch
- branch tradeoff fallback
- candidate option
- changed frame
- fallback
- gate
- move
- objective
- off-axis probe
- option payoff deliverable
- premise boundary unit
- previous surface
- probe
- probe scout unlock
- real fork
- rollback
- route comparison
- scope
- scout
- tradeoff
- tradeoff axis
- unblock
- unit
- unlock
- wedge

## BACK

- **Category:** lanes
- **Purpose:** follow-up / action-route candidate
- **Unique job:** BACK preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- action artifact blocker
- artifact
- assumption
- boundary
- bounded move
- branch
- branch tradeoff fallback
- candidate option
- changed frame
- fallback
- gate
- move
- objective
- off-axis probe
- option payoff deliverable
- premise boundary unit
- previous surface
- probe
- probe scout unlock
- real fork
- rollback
- route comparison
- scope
- scout
- tradeoff
- tradeoff axis
- unblock
- unit
- unlock
- wedge

## AUDIT

- **Category:** checks_guards
- **Purpose:** guard wave route for receipt truth, readability, or risk boundary
- **Unique job:** AUDIT preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** POPPER, SYNTHESIS, LLM_COUNCIL

### Salience drivers

- SAT
- SMT
- SMT solver
- UNSAT
- Z3
- activity
- agent
- audit trail
- benchmark
- bounded verification
- channel
- checked state
- clean finding
- clean verdict
- constraint satisfaction
- counterexample
- counterexample trace
- density matrix
- density matrix channel
- digital thread
- entity
- entity activity agent
- equivalence class
- evidence chain
- false closure
- finding
- finding severity repair
- finite model
- graph
- initial state
- input system output system
- invariant
- invariant violation
- manifold
- model checking
- operator
- operator channel
- path
- proof obligation
- provenance
- provenance record
- quantum channel
- receipt
- receipt evidence chain
- route truth
- route truth audit
- severity
- solver
- solver witness model
- source pointer
- state path counterexample
- state path witness
- tensor
- theory invariant counterexample
- traceability
- transition system trace
- witness

### People / schools / systems / methods

- provenance
- audit trail
- traceability

### Math / operator / geometry associations

- Z3
- SMT
- SAT
- UNSAT
- model checking
- invariant
- counterexample
- solver
- witness
- proof obligation
- finite model
- constraint satisfaction

## HYGIENE

- **Category:** checks_guards
- **Purpose:** guard wave route for receipt truth, readability, or risk boundary
- **Unique job:** HYGIENE preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** ORWELL, AUDIT

### Salience drivers

- George Orwell
- abstract fog
- active verb agency
- active verbs
- active voice
- bad abstraction
- cognitive load
- concrete naming
- concrete noun
- cut abstract fog
- cut the word
- dead metaphor
- duplicate section
- duplicate section removal
- emoji consistency
- euphemism
- everyday English
- format boundary
- format lint
- heading
- heading order
- heading section order
- inflated noun
- information architecture
- label
- linting
- noun verb state
- outline
- passive hiding
- plain English
- plain concrete naming
- plain sentence
- plain surface
- political language
- readability
- readability cognitive load
- readable surface
- say what happened
- scan path
- scan path label
- scannability
- section order
- short word
- spacing
- stale phrase
- surface polish
- visible agency
- wall text

## SECURITY

- **Category:** checks_guards
- **Purpose:** guard wave route for receipt truth, readability, or risk boundary
- **Unique job:** SECURITY preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** AUDIT, PUSHBACK

### Salience drivers

- OWASP
- asset
- asset mitigation
- asset threat mitigation
- attack surface
- authorization
- capability
- credential
- entry point
- entry point boundary
- exit point
- exposure
- least privilege
- least privilege access
- mitigation
- permission
- permission boundary
- permission secret exposure
- policy
- sandbox
- sandbox policy guardrail
- secret
- secret exposure
- threat model
- trust boundary
- unsafe default

### People / schools / systems / methods

- OWASP
- least privilege
- threat modeling

## LLM_COUNCIL

- **Category:** system_routes
- **Purpose:** independent multi-model or multi-route comparison wave
- **Unique job:** LLM_COUNCIL preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** SYNTHESIS, AUDIT

### Salience drivers

- adversarial review
- advisory receipt
- arbitration
- council rounds
- dissent preservation
- dissent preservation synthesis
- diverse reasoning paths
- ensemble disagreement
- independent assessment
- independent route comparison
- minority report
- model family
- model variance
- model variance signal
- peer review
- proposal debate arbitration
- round robin
- round robin council
- route comparison
- self-consistency
- source-aware filtering
- variance before merge
- variance signal

### People / schools / systems / methods

- ensemble disagreement
- peer review
- adversarial review

## ALL_A

- **Category:** compositions
- **Purpose:** integrated route bundle assembled from previous wave findings
- **Unique job:** ALL_A preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- Clausewitz
- Donella Meadows
- John Boyd
- Karl Popper
- Norbert Wiener
- OODA
- OODA loop
- Richard Feynman
- Stafford Beer
- Sunzi
- action artifact blocker
- activity
- agent
- apparatus
- apparatus and measurement
- apparatus observable measurement
- artifact
- assumption
- attractor
- audit trail
- balancing loop
- basic statement
- basic statement corroboration
- benchmark
- bold hypothesis
- boundary
- boundary attractor coupling
- bounded move
- branch
- branch tradeoff fallback
- buffer
- buffer and delay
- calculation
- calibrated instrument
- calibration
- calibration measurement error
- campaign
- campaign sequence
- campaign tempo reserve
- candidate option
- center of gravity
- changed frame
- checked state
- claim falsifier check
- clean finding
- clean verdict
- comparison
- complex adaptive system
- conjecture
- conjecture and refutation
- conjecture refutation correction
- contact with nature
- controller
- corroboration
- counterexample
- counterinstance
- coupling
- critical discussion
- critical rationalism
- cybernetics
- decisive point
- decisive point initiative
- delay
- demarcation
- digital thread
- disposition
- do the experiment
- emergence
- entity
- entity activity agent
- error correction
- estimate
- evidence chain
- example
- experiment
- fallback
- false closure
- falsifiability
- falsifier
- falsifier before agreement

## ALL_B

- **Category:** compositions
- **Purpose:** integrated route bundle assembled from previous wave findings
- **Unique job:** ALL_B preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- Daoism
- David Hume
- Karl Popper
- Richard Feynman
- Zhuangzi
- activity
- agent
- apparatus
- apparatus and measurement
- apparatus observable measurement
- association
- audit trail
- basic statement
- basic statement corroboration
- benchmark
- bold hypothesis
- butterfly dream
- calculation
- calibrated instrument
- calibration
- calibration measurement error
- checked experience
- checked state
- claim falsifier check
- clean finding
- clean verdict
- common life
- comparison
- conjecture
- conjecture and refutation
- conjecture refutation correction
- contact with nature
- convention
- corroboration
- counterexample
- counterinstance
- critical discussion
- critical rationalism
- custom
- custom and habit
- custom habit belief
- demarcation
- digital thread
- do the experiment
- empiricism
- entity
- entity activity agent
- error correction
- estimate
- evidence chain
- example
- experience
- experience and testimony
- experience testimony support
- experiment
- fact observation experience
- fallibilism
- false closure
- falsifiability
- falsifier
- falsifier before agreement
- finding
- finding severity repair
- goblet words
- habit
- idea
- impression
- impression and idea
- impression idea association
- initial state
- instrument
- invalidating detail
- live readings
- live readings exclusion
- matter of fact
- measured difference
- measurement
- memory and testimony
- memory testimony probability
- modest judgment

## ALL_C

- **Category:** compositions
- **Purpose:** integrated route bundle assembled from previous wave findings
- **Unique job:** ALL_C preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- George Orwell
- OWASP
- Toyota Production System
- abnormality
- abstract fog
- active verb agency
- active verbs
- active voice
- activity
- agent
- andon
- asset
- asset mitigation
- asset threat mitigation
- attack surface
- audit trail
- authorization
- bad abstraction
- benchmark
- bottleneck
- capability
- checked state
- clean finding
- clean verdict
- cognitive load
- concrete naming
- concrete noun
- counterexample
- credential
- cut abstract fog
- cut the word
- dead metaphor
- digital thread
- duplicate section
- duplicate section removal
- emoji consistency
- entity
- entity activity agent
- entry point
- entry point boundary
- euphemism
- everyday English
- evidence chain
- exit point
- exposure
- false closure
- finding
- finding severity repair
- flow rework leverage
- format boundary
- format lint
- handoff
- handoff friction
- heading
- heading order
- heading section order
- incident review
- inflated noun
- information architecture
- initial state
- inventory hides problem
- jidoka
- jidoka andon
- jidoka andon abnormality
- kaizen
- kanban
- label
- lead time
- lean manufacturing
- least privilege
- least privilege access
- linting
- mitigation
- noun verb state
- observability
- outline
- passive hiding
- path
- permission
- permission boundary

## ALL_D

- **Category:** compositions
- **Purpose:** integrated route bundle assembled from previous wave findings
- **Unique job:** ALL_D preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** none listed

### Salience drivers

- Donella Meadows
- Norbert Wiener
- Stafford Beer
- action artifact blocker
- activity
- adversarial review
- advisory receipt
- agent
- arbitration
- artifact
- assumption
- attractor
- audit trail
- balancing loop
- benchmark
- boundary
- boundary attractor coupling
- bounded move
- branch
- branch tradeoff fallback
- buffer
- buffer and delay
- candidate option
- changed frame
- checked state
- clean finding
- clean verdict
- complex adaptive system
- controller
- council rounds
- counterexample
- coupling
- cybernetics
- delay
- digital thread
- dissent preservation
- dissent preservation synthesis
- diverse reasoning paths
- emergence
- ensemble disagreement
- entity
- entity activity agent
- evidence chain
- fallback
- false closure
- feedback
- feedback loop
- finding
- finding severity repair
- flow
- gate
- goal information feedback
- independent assessment
- independent route comparison
- information flow
- initial state
- leverage point
- loop incentive coupling
- minority report
- model family
- model variance
- model variance signal
- monitor
- monitor controller feedback
- move
- objective
- off-axis probe
- option payoff deliverable
- path
- peer review
- premise boundary unit
- previous surface
- probe
- probe scout unlock
- proposal debate arbitration
- provenance
- provenance record
- real fork
- receipt
- receipt evidence chain

## SYNTHESIS

- **Category:** controller_acts
- **Purpose:** post-receipt controller composition process
- **Unique job:** SYNTHESIS preserves its own positive salience basin and execution contract.
- **Non-job:** Do not become decorative, unreceipted, or controller-local fake plurality.
- **Inputs:** assigned mini-MMM, task card, relevant receipts, source/tools when needed
- **Outputs:** bounded result, blocker/defer reason, receipt, or candidate prompt
- **Subagent contract:** If visible as ran, must be spawned or marked blocked/deferred with receipt truth.
- **Receipt requirement:** status, mini_mmm_loaded_before_task, checked, concluded, open, evidence, artifact_or_output
- **Collapse signs:** route appears as a label without a receipt; route returns same reasoning shape as another route; route is merged before audit
- **Nearest neighbors:** HUME, AUDIT, LLM_COUNCIL

### Salience drivers

- accepted receipt
- accepted rejected open
- activity
- adversarial review
- advisory receipt
- agent
- arbitration
- audit trail
- benchmark
- branch remainder
- branch remainder preserved
- checked state
- clean finding
- clean verdict
- compose without collapse
- composition
- controller synthesis
- council rounds
- counterexample
- digital thread
- dissent preservation
- dissent preservation synthesis
- diverse reasoning paths
- ensemble disagreement
- entity
- entity activity agent
- evidence chain
- false closure
- finding
- finding severity repair
- held tension
- independent assessment
- independent route comparison
- initial state
- minority report
- model family
- model variance
- model variance signal
- non-collapse
- path
- peer review
- proposal debate arbitration
- provenance
- provenance record
- receipt
- receipt evidence chain
- receipt set
- receipt tension composition
- rejected receipt
- round robin
- round robin council
- route comparison
- route truth
- route truth audit
- self-consistency
- semantic preservation
- severity
- source pointer
- source-aware filtering
- state path counterexample
- surviving split
- traceability
- variance before merge
- variance signal

### People / schools / systems / methods

- non-collapse composition
- receipt set

### Math / operator / geometry associations

- Z3
- SMT
- SAT
- UNSAT
- model checking
- invariant
- counterexample
- solver
- witness
- proof obligation
- finite model
- constraint satisfaction
