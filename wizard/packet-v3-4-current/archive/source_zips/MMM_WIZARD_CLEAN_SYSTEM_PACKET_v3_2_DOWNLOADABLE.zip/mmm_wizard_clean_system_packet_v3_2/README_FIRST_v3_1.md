# MMM Wizard Clean System Packet v3.1

## What this fixes

- FULL is actually full and lays out the rules.
- COMPACT is usable, not a skeleton.
- Universal core no longer contains full voice/lane definitions.
- Definitions stay in definitions/.
- Subagents do not boot the main MMM.
- Audit is not a default output section.
- Quality/audit score belongs in footer.
- Follow-up is where lanes/compositions normally appear.
- Full candidate bank can include voices, checks/guards, system routes, and compositions.
- Final Follow-up is audited useful subset.
- Two sizes only: FULL and COMPACT.

## Read first

1. `universal_core/WIZARD_UNIVERSAL_CORE_FULL_v3_1.md`
2. `mmm/main/compact/md/MMM_MAIN_COMPACT_v3_1.md`
3. `definitions/full/md/MMM_DEFINITIONS_FULL_v3_1.md`
4. `universal_core/WIZARD_UNIVERSAL_CORE_COMPACT_v3_1.md`

## Boot

Main agent:
1. main MMM
2. universal core
3. task

Subagent:
1. assigned mini-MMM only
2. task card
3. source/tools

Negative/reference material never boots.
