import { readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { loadProjectEvaluatorPacks } from './index.ts';

const repoRoot = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const packDir = join(repoRoot, 'core/eval/evaluators/cr_scc_quotient_parity');
const fixturesDir = join(packDir, 'fixtures');

interface ScoreResult {
  schema: string;
  evaluator_id: string;
  passed: boolean;
  decision: string;
  reason: string;
  measurements: {
    schema: string;
    variables: Record<string, { value: unknown; confidence: number; evidence_count: number }>;
  };
}

describe('cr_scc_quotient_parity evaluator pack', () => {
  it('is discovered as a shipped evaluator pack', async () => {
    const packs = await loadProjectEvaluatorPacks({
      projectRoot: repoRoot,
      evaluatorId: 'cr_scc_quotient_parity',
    });

    expect(packs).toHaveLength(1);
    expect(packs[0]?.manifest).toMatchObject({
      schema: 'lev.evaluator_pack.v1',
      evaluator_id: 'cr_scc_quotient_parity',
      owner: 'core/eval',
      kind: 'shipped_evaluator_pack',
    });
    expect(packs[0]?.diagnostics).toEqual([]);
    expect(packs[0]?.evidence_refs).toEqual(expect.arrayContaining([
      expect.objectContaining({
        kind: 'manifest',
        path: 'core/eval/evaluators/cr_scc_quotient_parity/cr_scc_quotient_parity.eval.yaml',
        exists: true,
      }),
      expect.objectContaining({
        kind: 'entrypoint',
        label: 'sensor',
        path: 'core/eval/evaluators/cr_scc_quotient_parity/companions/sensor.mjs',
        exists: true,
      }),
      expect.objectContaining({
        kind: 'policy',
        label: 'gate',
        path: 'core/eval/evaluators/cr_scc_quotient_parity/policies/gate-policy.yaml',
        exists: true,
      }),
    ]));
  });

  it('passes real Codex-Ratchet Julia and JAX SCC quotient evidence', async () => {
    const result = await scoreFixture('scc-quotient-parity-pass.trace.json');

    expect(result.schema).toBe('lev.evaluator.result.v1');
    expect(result.evaluator_id).toBe('cr_scc_quotient_parity');
    expect(result.passed).toBe(true);
    expect(result.decision).toBe('pass');
    expect(result.measurements.variables.max_abs_diff.value).toBe(0);
    expect(result.measurements.variables.engines_agree.value).toBe(true);
    expect(result.measurements.variables.engines_present.value).toBe(true);
    expect(result.measurements.variables.negative_control_present.value).toBe(true);
  });

  it('blocks when one SCC quotient observable drifts beyond tolerance', async () => {
    const result = await scoreFixture('scc-quotient-parity-adversarial.trace.json');

    expect(result.passed).toBe(false);
    expect(result.decision).toBe('block');
    expect(result.measurements.variables.max_abs_diff.value).toBe(1);
    expect(result.measurements.variables.engines_agree.value).toBe(false);
  });

  it('blocks when a required engine lane is missing', async () => {
    const result = await scoreFixture('scc-quotient-parity-missing-lane.trace.json');

    expect(result.passed).toBe(false);
    expect(result.decision).toBe('block');
    expect(result.measurements.variables.engines_present.value).toBe(false);
    expect(result.reason).toContain('required provider lanes');
  });

  it('blocks provider evidence whose content address does not match its fields', async () => {
    const result = await scoreFixture('scc-quotient-parity-bad-address.trace.json');

    expect(result.passed).toBe(false);
    expect(result.decision).toBe('block');
    expect(result.reason).toContain('content_address_mismatch');
  });
});

async function scoreFixture(name: string): Promise<ScoreResult> {
  const [{ score }, fixture] = await Promise.all([
    loadSensor(),
    readFixture(name),
  ]);
  return score(fixture) as ScoreResult;
}

async function loadSensor(): Promise<{ score(input: unknown): unknown }> {
  return import(pathToFileURL(join(packDir, 'companions/sensor.mjs')).href) as Promise<{ score(input: unknown): unknown }>;
}

async function readFixture(name: string): Promise<unknown> {
  return JSON.parse(await readFile(join(fixturesDir, name), 'utf8')) as unknown;
}
