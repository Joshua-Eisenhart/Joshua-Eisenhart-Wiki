const PROVIDER_SCHEMA = 'lev.sim_eval.provider_evidence.v1';
const EVALUATOR_ID = 'cr_scc_quotient_parity';
const CONTENT_ADDRESS_PREFIX = 'sim-eval:fnv1a32:';
const FNV_OFFSET = 0x811c9dc5;
const FNV_PRIME = 0x01000193;
const REQUIRED_ENGINE_LANES = Object.freeze(['sim.julia', 'sim.jax']);
const DEFAULT_OBSERVABLE_NAMES = Object.freeze([
  'scc_count.map_plus',
  'scc_count.map_minus',
  'quotient_class_count.map_plus',
  'quotient_class_count.map_minus',
]);
const PROVIDER_LANE_IDS = Object.freeze([
  'guard.compiled',
  'sim.jax',
  'sim.torch',
  'sim.julia',
  'proof.smt',
]);
const DEFAULT_THRESHOLDS = Object.freeze({
  max_abs_diff_max: 0,
  min_engine_lanes: 2,
});
const FORBIDDEN_PROVIDER_STATUSES = Object.freeze([
  'evaluated',
  'pass',
  'fail',
  'not_evaluated',
]);
const FORBIDDEN_PROVIDER_FIELDS = Object.freeze([
  'verdict',
  'EvalVerdict',
  'gate_proof',
  'GateProof',
  'proof_bundle',
  'ProofBundle',
  'effect_receipt',
  'EffectReceipt',
  'run_seal',
  'RunSeal',
]);

export function score(input) {
  const providerEvidence = providerEvidenceFrom(input);
  const observableNames = observableNamesFrom(input);
  const toleranceResult = toleranceFrom(input);
  const evidenceRefs = providerEvidence.flatMap(evidenceRefsFromRecord);
  const blocked = (reason, partial = {}) => result('block', reason, {
    maxAbsDiff: partial.maxAbsDiff ?? null,
    enginesAgree: partial.enginesAgree ?? false,
    enginesPresent: partial.enginesPresent ?? false,
    negativeControlPresent: partial.negativeControlPresent ?? false,
    engineEvidenceCount: partial.engineEvidenceCount ?? providerEvidence.length,
    evidenceRefs,
  });

  if (providerEvidence.length === 0) {
    return blocked('required provider lanes sim.julia and sim.jax are missing');
  }
  if (observableNames.length === 0) {
    return blocked('declared shared observable_name is missing');
  }
  if (!toleranceResult.ok) {
    return blocked('declared tolerance is missing or malformed');
  }

  const lanes = new Map();
  for (const record of providerEvidence) {
    if (hasTruthMintingShape(record)) {
      return blocked('provider evidence contains forbidden verdict or proof-shaped fields');
    }
    if (!isProviderRecord(record)) {
      return blocked('provider evidence is malformed');
    }
    if (!contentAddressMatches(record)) {
      return blocked('provider evidence content_address_mismatch: content_address does not match recomputed FNV-1a-32');
    }
    if (!REQUIRED_ENGINE_LANES.includes(record.lane_id)) continue;
    if (lanes.has(record.lane_id)) {
      return blocked(`provider evidence has duplicate required lane ${record.lane_id}`);
    }
    if (record.status !== 'non_authoritative_input') {
      return blocked(`provider lane ${record.lane_id} did not emit non_authoritative_input`);
    }
    lanes.set(record.lane_id, record);
  }

  const enginesPresent = REQUIRED_ENGINE_LANES.every((laneId) => lanes.has(laneId))
    && lanes.size >= DEFAULT_THRESHOLDS.min_engine_lanes;
  if (!enginesPresent) {
    return blocked('required provider lanes sim.julia and sim.jax are missing', {
      enginesPresent,
      engineEvidenceCount: lanes.size,
    });
  }

  const numericPairs = [];
  for (const observableName of observableNames) {
    const juliaValue = numericFact(lanes.get('sim.julia'), observableName);
    const jaxValue = numericFact(lanes.get('sim.jax'), observableName);
    if (!juliaValue.ok || !jaxValue.ok) {
      return blocked(`required numeric observable "${observableName}" is missing or malformed`, {
        enginesPresent,
        engineEvidenceCount: lanes.size,
      });
    }
    numericPairs.push([juliaValue.value, jaxValue.value]);
  }

  const maxAbsDiff = round(Math.max(...numericPairs.map(([juliaValue, jaxValue]) => Math.abs(juliaValue - jaxValue))));
  const negativeControlPresent = REQUIRED_ENGINE_LANES.every((laneId) => factValue(lanes.get(laneId), 'negative_control_present') === true);
  const enginesAgree = maxAbsDiff <= toleranceResult.value;
  const passed = enginesAgree && enginesPresent && negativeControlPresent;

  if (!negativeControlPresent) {
    return blocked('required negative control evidence is missing', {
      maxAbsDiff,
      enginesAgree,
      enginesPresent,
      negativeControlPresent,
      engineEvidenceCount: lanes.size,
    });
  }
  if (!enginesAgree) {
    return blocked('engine observable difference exceeds tolerance', {
      maxAbsDiff,
      enginesAgree,
      enginesPresent,
      negativeControlPresent,
      engineEvidenceCount: lanes.size,
    });
  }

  return result(passed ? 'pass' : 'block', 'Julia and JAX provider lanes agree within deterministic tolerance', {
    maxAbsDiff,
    enginesAgree,
    enginesPresent,
    negativeControlPresent,
    engineEvidenceCount: lanes.size,
    evidenceRefs,
  });
}

function result(decision, reason, measurements) {
  const passed = decision === 'pass';
  return {
    schema: 'lev.evaluator.result.v1',
    evaluator_id: EVALUATOR_ID,
    passed,
    decision,
    action: routeAction(decision),
    reason,
    measurements: {
      schema: 'lev.measurement.v1',
      variables: {
        max_abs_diff: triple(measurements.maxAbsDiff, measurements.maxAbsDiff === null ? 0 : 1, measurements.engineEvidenceCount),
        engines_agree: triple(measurements.enginesAgree, 1, measurements.engineEvidenceCount),
        engines_present: triple(measurements.enginesPresent, 1, measurements.engineEvidenceCount),
        negative_control_present: triple(measurements.negativeControlPresent, 1, measurements.engineEvidenceCount),
      },
    },
    evidence_refs: measurements.evidenceRefs,
    required_repairs: passed ? [] : ['repair provider evidence or rerun required sim.julia and sim.jax lanes before gate admission'],
  };
}

function providerEvidenceFrom(input) {
  if (Array.isArray(input)) return input;
  if (!isRecord(input)) return [];
  if (Array.isArray(input.provider_evidence)) return input.provider_evidence;
  if (Array.isArray(input.provider_evidence_refs)) return input.provider_evidence_refs;
  return [];
}

function observableNamesFrom(input) {
  if (!isRecord(input)) return [];
  if (Array.isArray(input.observable_names)) {
    return input.observable_names
      .filter((name) => typeof name === 'string')
      .map((name) => name.trim())
      .filter(Boolean);
  }
  const name = typeof input.observable_name === 'string'
    ? input.observable_name
    : typeof input.shared_observable_name === 'string'
      ? input.shared_observable_name
      : undefined;
  return typeof name === 'string' && name.trim() !== '' ? [name.trim()] : [...DEFAULT_OBSERVABLE_NAMES];
}

function toleranceFrom(input) {
  if (!isRecord(input)) return { ok: true, value: DEFAULT_THRESHOLDS.max_abs_diff_max };
  if (Object.hasOwn(input, 'tolerance')) {
    return finiteNonNegative(input.tolerance)
      ? { ok: true, value: input.tolerance }
      : { ok: false };
  }
  if (isRecord(input.thresholds) && Object.hasOwn(input.thresholds, 'max_abs_diff_max')) {
    return finiteNonNegative(input.thresholds.max_abs_diff_max)
      ? { ok: true, value: input.thresholds.max_abs_diff_max }
      : { ok: false };
  }
  return { ok: true, value: DEFAULT_THRESHOLDS.max_abs_diff_max };
}

function isProviderRecord(value) {
  return isRecord(value)
    && value.schema === PROVIDER_SCHEMA
    && PROVIDER_LANE_IDS.includes(value.lane_id)
    && (value.status === 'evaluation_error' || value.status === 'non_authoritative_input')
    && hasText(value.subject_ref)
    && Number.isInteger(value.generation)
    && hasText(value.requested_at)
    && Number.isFinite(Date.parse(value.requested_at))
    && hasText(value.content_address)
    && value.content_address.startsWith(CONTENT_ADDRESS_PREFIX)
    && Array.isArray(value.refs)
    && value.refs.every(isEvidenceRef)
    && Array.isArray(value.facts)
    && value.facts.every(isFact)
    && isRecord(value.provenance)
    && value.provenance.source_package === '@lev-os/sim-eval'
    && value.provenance.provider_id === value.lane_id
    && value.provenance.command === null
    && value.provenance.bounded === true
    && providerStatusShapeIsValid(value);
}

function contentAddressMatches(record) {
  return record.content_address === contentAddressForEvidence(record);
}

function contentAddressForEvidence(evidence) {
  const errorFields = errorFieldsForAddress(evidence);
  const serialized = [
    evidence.schema,
    evidence.lane_id,
    evidence.status,
    evidence.subject_ref,
    String(evidence.generation),
    evidence.requested_at,
    evidence.refs.map(formatEvidenceRef).join('\n'),
    evidence.facts.map(formatFact).join('\n'),
    evidence.provenance.source_package,
    evidence.provenance.provider_id,
    'command:null',
    'bounded:true',
    ...errorFields,
  ].join('\u001f');

  return `${CONTENT_ADDRESS_PREFIX}${fnv1a32(serialized)}`;
}

function errorFieldsForAddress(evidence) {
  if (evidence.status === 'non_authoritative_input') {
    return ['error:null'];
  }
  return [
    evidence.error.reason_code,
    evidence.error.detail,
    'retryable:false',
  ];
}

function fnv1a32(value) {
  let hash = FNV_OFFSET;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, FNV_PRIME);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

function formatEvidenceRef(ref) {
  return `${ref.kind}:${ref.ref}`;
}

function formatFact(fact) {
  return `${fact.name}:${String(fact.value)}`;
}

function providerStatusShapeIsValid(value) {
  if (value.status === 'non_authoritative_input') {
    return !Object.hasOwn(value, 'error');
  }
  return isRecord(value.error)
    && value.error.reason_code === 'provider_unavailable'
    && hasText(value.error.detail)
    && value.error.retryable === false;
}

function evidenceRefsFromRecord(record) {
  if (!isRecord(record) || typeof record.content_address !== 'string') return [];
  return [{
    kind: 'sim_eval_provider_evidence',
    ref: record.content_address,
    exists: true,
  }];
}

function numericFact(record, name) {
  const value = factValue(record, name);
  return typeof value === 'number' && Number.isFinite(value)
    ? { ok: true, value }
    : { ok: false };
}

function factValue(record, name) {
  if (!isRecord(record) || !Array.isArray(record.facts)) return undefined;
  return record.facts.find((fact) => isRecord(fact) && fact.name === name)?.value;
}

function isEvidenceRef(value) {
  return isRecord(value) && hasText(value.kind) && hasText(value.ref);
}

function isFact(value) {
  return isRecord(value)
    && hasText(value.name)
    && (
      value.value === null
      || typeof value.value === 'string'
      || typeof value.value === 'boolean'
      || (typeof value.value === 'number' && Number.isFinite(value.value))
    );
}

function hasTruthMintingShape(value) {
  if (Array.isArray(value)) return value.some(hasTruthMintingShape);
  if (!isRecord(value)) return false;
  if (FORBIDDEN_PROVIDER_STATUSES.includes(value.status)) return true;
  for (const field of FORBIDDEN_PROVIDER_FIELDS) {
    if (Object.hasOwn(value, field)) return true;
  }
  return Object.values(value).some(hasTruthMintingShape);
}

function triple(value, confidence, evidenceCount) {
  return {
    value,
    confidence,
    evidence_count: evidenceCount,
  };
}

function routeAction(decision) {
  return {
    pass: 'keep',
    warn: 'hold',
    repair: 'repair',
    block: 'block',
  }[decision] ?? 'hold';
}

function finiteNonNegative(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0;
}

function round(value) {
  return Math.round(value * 1000000000000) / 1000000000000;
}

function hasText(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function isRecord(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
