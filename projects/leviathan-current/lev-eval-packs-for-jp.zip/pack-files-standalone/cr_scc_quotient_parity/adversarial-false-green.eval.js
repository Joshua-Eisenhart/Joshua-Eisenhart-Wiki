export default {
  id: 'cr-scc-quotient-parity-adversarial-trace-eval',
  target: './companions/sensor.mjs',
  flowmind: './flows/measure.flow.yaml',
  fixtures: {
    trace: './fixtures/scc-quotient-parity-adversarial.trace.json',
  },
  greenChecks: [
    'adversarial fixture keeps both provider lanes present',
    'deterministic sensor blocks a perturbed SCC quotient value beyond tolerance',
  ],
  redChecks: [
    'matching provider schema cannot create a false green',
    'one perturbed engine value cannot pass through the gate',
  ],
  traceCases: [{
    id: 'perturbed-scc-provider-evidence-fixture',
    claim: 'A single JAX SCC quotient observable perturbation beyond tolerance remains provider evidence only and must block when scored.',
    subjectFixture: 'trace',
    expectations: {
      schema: 'lev.cr_scc_quotient_parity.trace.v1',
      subject_ref: 'codex-ratchet:system_v7/sims/mixed_radix_endofunction_scc_terminal_quotient_under_z2_involution_v0',
      tolerance: 0,
    },
  }],
};
