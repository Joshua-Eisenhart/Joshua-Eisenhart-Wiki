export default {
  id: 'cr-scc-quotient-parity-pass-trace-eval',
  target: './companions/sensor.mjs',
  flowmind: './flows/measure.flow.yaml',
  fixtures: {
    trace: './fixtures/scc-quotient-parity-pass.trace.json',
  },
  greenChecks: [
    'real Codex-Ratchet Julia and JAX provider evidence is present',
    'real SCC quotient observables can be scored by deterministic companion sensor',
  ],
  redChecks: [
    'provider evidence cannot carry its own verdict',
    'engine agreement is not accepted without companion scoring',
  ],
  traceCases: [{
    id: 'real-scc-provider-evidence-fixture',
    claim: 'Real mixed_radix SCC Julia and JAX result facts provide the input for a pass decision.',
    subjectFixture: 'trace',
    expectations: {
      schema: 'lev.cr_scc_quotient_parity.trace.v1',
      subject_ref: 'codex-ratchet:system_v7/sims/mixed_radix_endofunction_scc_terminal_quotient_under_z2_involution_v0',
      tolerance: 0,
    },
  }],
};
