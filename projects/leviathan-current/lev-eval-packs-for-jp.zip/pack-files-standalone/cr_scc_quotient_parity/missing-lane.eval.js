export default {
  id: 'cr-scc-quotient-parity-missing-lane-trace-eval',
  target: './companions/sensor.mjs',
  flowmind: './flows/measure.flow.yaml',
  fixtures: {
    trace: './fixtures/scc-quotient-parity-missing-lane.trace.json',
  },
  greenChecks: [
    'fixture preserves a valid sim.julia provider evidence record',
    'deterministic sensor blocks when sim.jax is absent',
  ],
  redChecks: [
    'one engine lane cannot prove SCC quotient parity',
    'missing lane cannot silently pass as agreement',
  ],
  traceCases: [{
    id: 'missing-scc-provider-lane-fixture',
    claim: 'A single engine lane is incomplete provider evidence and must block when scored.',
    subjectFixture: 'trace',
    expectations: {
      schema: 'lev.cr_scc_quotient_parity.trace.v1',
      subject_ref: 'codex-ratchet:system_v7/sims/mixed_radix_endofunction_scc_terminal_quotient_under_z2_involution_v0',
      tolerance: 0,
    },
  }],
};
