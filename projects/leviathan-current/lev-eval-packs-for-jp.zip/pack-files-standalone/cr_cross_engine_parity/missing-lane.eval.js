export default {
  id: 'cr-cross-engine-parity-missing-lane-trace-eval',
  target: './companions/sensor.mjs',
  flowmind: './flows/measure.flow.yaml',
  fixtures: {
    trace: './fixtures/probe-quotient-parity-missing-lane.trace.json',
  },
  greenChecks: [
    'fixture preserves a valid sim.julia provider evidence record',
    'deterministic sensor blocks when sim.jax is absent',
  ],
  redChecks: [
    'one engine lane cannot prove cross-engine parity',
    'missing lane cannot silently pass as agreement',
  ],
  traceCases: [{
    id: 'missing-provider-lane-fixture',
    claim: 'A single engine lane is incomplete provider evidence and must block when scored.',
    subjectFixture: 'trace',
    expectations: {
      schema: 'lev.cr_cross_engine_parity.trace.v1',
      subject_ref: 'codex-ratchet:system_v7/sims/probe_quotient_fingerprint_floor_v1',
      observable_name: 'quotient_class_count_full',
      tolerance: 0,
    },
  }],
};
