export default {
  id: 'cr-cross-engine-parity-bad-address-trace-eval',
  target: './companions/sensor.mjs',
  flowmind: './flows/measure.flow.yaml',
  fixtures: {
    trace: './fixtures/probe-quotient-parity-bad-address.trace.json',
  },
  greenChecks: [
    'fixture keeps valid provider evidence shape and required engine lanes present',
    'deterministic sensor recomputes provider evidence content_address before scoring parity',
  ],
  redChecks: [
    'valid sim-eval content address prefix alone cannot create a false green',
    'provider evidence with a mismatched content_address must block before numeric agreement is trusted',
  ],
  traceCases: [{
    id: 'bad-content-address-provider-evidence-fixture',
    claim: 'A provider record with a valid-looking but mismatched content_address remains provider evidence only and must block when scored.',
    subjectFixture: 'trace',
    expectations: {
      schema: 'lev.cr_cross_engine_parity.trace.v1',
      subject_ref: 'codex-ratchet:system_v7/sims/probe_quotient_fingerprint_floor_v1',
      observable_name: 'quotient_class_count_full',
      tolerance: 0,
    },
  }],
};
