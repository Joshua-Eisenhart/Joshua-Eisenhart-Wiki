export default {
  id: 'cr-cross-engine-parity-pass-trace-eval',
  target: './companions/sensor.mjs',
  flowmind: './flows/measure.flow.yaml',
  fixtures: {
    trace: './fixtures/probe-quotient-parity-pass.trace.json',
  },
  greenChecks: [
    'real Codex-Ratchet Julia and JAX provider evidence is present',
    'real engine observable can be scored by deterministic companion sensor',
  ],
  redChecks: [
    'provider evidence cannot carry its own verdict',
    'engine agreement is not accepted without companion scoring',
  ],
  traceCases: [{
    id: 'real-provider-evidence-fixture',
    claim: 'Real probe_quotient_fingerprint_floor_v1 Julia and JAX result facts provide the input for a pass decision.',
    subjectFixture: 'trace',
    expectations: {
      schema: 'lev.cr_cross_engine_parity.trace.v1',
      subject_ref: 'codex-ratchet:system_v7/sims/probe_quotient_fingerprint_floor_v1',
      observable_name: 'quotient_class_count_full',
      tolerance: 0,
    },
  }],
};
