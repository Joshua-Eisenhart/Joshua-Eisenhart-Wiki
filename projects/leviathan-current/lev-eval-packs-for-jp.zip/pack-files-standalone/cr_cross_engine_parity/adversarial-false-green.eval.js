export default {
  id: 'cr-cross-engine-parity-adversarial-trace-eval',
  target: './companions/sensor.mjs',
  flowmind: './flows/measure.flow.yaml',
  fixtures: {
    trace: './fixtures/probe-quotient-parity-adversarial.trace.json',
  },
  greenChecks: [
    'adversarial fixture keeps both provider lanes present',
    'deterministic sensor blocks a perturbed engine value beyond tolerance',
  ],
  redChecks: [
    'matching provider schema cannot create a false green',
    'one perturbed engine value cannot pass through the gate',
  ],
  traceCases: [{
    id: 'perturbed-provider-evidence-fixture',
    claim: 'A single JAX observable perturbation beyond tolerance remains provider evidence only and must block when scored.',
    subjectFixture: 'trace',
    expectations: {
      schema: 'lev.cr_cross_engine_parity.trace.v1',
      subject_ref: 'codex-ratchet:system_v7/sims/probe_quotient_fingerprint_floor_v1',
      observable_name: 'quotient_class_count_full',
      tolerance: 0,
    },
  }],
};
